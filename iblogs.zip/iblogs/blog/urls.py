from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from .views import *
from blog import views

urlpatterns = [
    path('', home),
    path('home', views.home, name='home'), 
    path('blog/<slug:url>', post),
    path('category/<slug:url>',category)
]
